# 07. Web 页面处理与前端嵌入规范 (Web UI, Templates & Security)

本规范指导大模型在 Go 项目中开发全栈 Web 页面与管理后台。**核心原则：优先采用现代原生 Web 标准（Vanilla JS/CSS/HTML5）、Go 模板（SSR）结合 API 渐进增强、对齐 shadcn 现代极简设计美学、通过 `//go:embed` 交付零外部依赖的单一二进制文件，并严密贯彻 Web 安全防护。**

---

## 1. 架构核心原则 (Architecture Principles)

```mermaid
graph LR
    subgraph Browser ["Modern Browser (Vanilla Web)"]
        HTML[Go SSR Template + HTML5]
        CSS[shadcn CSS Tokens & Variables]
        JS[Modern Vanilla JS fetch/DOM]
    end

    subgraph GoBinary ["Single Go Binary (//go:embed)"]
        FS[embed.FS: templates/ & static/]
        Router[net/http / chi / Gin Router]
        Auth[Auth & CSRF Middleware]
        API[RESTful JSON Handlers]
        Renderer[html/template Engine]
    end

    HTML -.->|1. Initial Page Load (SSR)| Renderer
    JS -.->|2. Async Data & Actions (Fetch)| API
    Router --> Auth --> Renderer & API
    FS --> Renderer
    FS --> Router
```

1. **零外部构建工具链（No Node.js Required）**：
   - 优先采用原生现代 CSS 与原生 JS，避免强绑定复杂的 Node.js / Webpack / Vite 构建流水线。
2. **SSR + API 渐进增强（Hybrid Rendering）**：
   - **首屏与核心数据**：由 Go `html/template` 在服务端完成渲染，保证页面秒开与良好的 SEO。
   - **交互与复杂操作**：使用原生 Modern JavaScript (`fetch()`, `async/await`, `CustomEvent`) 异步调用后端 JSON API 进行局部数据更新与交互。
3. **单二进制全打包（Single Binary Distribution）**：
   - 所有静态资源（CSS、JS、图片、SVG、字体）与 HTML 模板文件必须通过 `//go:embed` 编译进单一二进制文件，部署时无需附带任何静态文件夹。
4. **强安全性基线（Security by Default）**：
   - 必须配备 Session Cookie 加密与防篡改、CSRF Token 防御、安全响应头（CSP、X-Frame-Options 等）以及基于 `bcrypt` 的密码哈希与 RBAC 权限控制。

---

## 2. 单二进制文件嵌入规范 (`//go:embed`)

### 2.1 目录结构与嵌入方式
在项目中建议将模板与静态资源组织在 `web/` 或 `internal/web/` 下：

```text
my-service/
├── internal/
│   └── web/
│       ├── assets.go          # embed.FS 定义与辅助加载函数
│       ├── templates/         # HTML 模板文件
│       │   ├── layouts/
│       │   │   └── base.html  # 基础骨架（Header/Nav/Footer/Dark Mode）
│       │   ├── partials/      # 局部组件（Card, Table, Pagination）
│       │   └── pages/         # 业务页面（login.html, dashboard.html）
│       └── static/            # 静态资源
│           ├── css/
│           │   └── shadcn.css # 纯原生现代 CSS 样式系统
│           ├── js/
│           │   └── app.js     # 原生辅助脚本（Toast, Dialog, Fetch Wrapper）
│           └── img/
│               └── logo.svg
```

### 2.2 `assets.go` 标准实现
```go
package web

import (
	"embed"
	"html/template"
	"io/fs"
	"net/http"
	"os"
)

//go:embed templates/* static/*
var embeddedFS embed.FS

type AssetManager struct {
	isDev bool
}

func NewAssetManager(isDev bool) *AssetManager {
	return &AssetManager{isDev: isDev}
}

// GetStaticFS 获取静态资源文件系统（支持开发模式本地热读与生产模式内嵌）
func (m *AssetManager) GetStaticFS() http.FileSystem {
	if m.isDev {
		// 开发模式：直接读取本地磁盘，修改 CSS/JS 无需重新编译
		return http.Dir("internal/web/static")
	}
	// 生产模式：使用内嵌文件系统
	sub, _ := fs.Sub(embeddedFS, "static")
	return http.FS(sub)
}

// ParseTemplates 编译加载模板
func (m *AssetManager) ParseTemplates(funcMap template.FuncMap) (*template.Template, error) {
	tmpl := template.New("").Funcs(funcMap)

	if m.isDev {
		return tmpl.ParseGlob("internal/web/templates/**/*.html")
	}
	return tmpl.ParseFS(embeddedFS, "templates/**/*.html", "templates/*.html")
}
```

---

## 3. shadcn/ui 纯现代 CSS 规范 (Native Modern CSS)

无需引入 Tailwind 工具链，直接使用现代原生 CSS 特性（CSS Custom Properties / Variables, `:has()`, `backdrop-filter`, `accent-color`）对齐 shadcn 视觉风格。

### 3.1 核心设计变量 (`shadcn_tokens.css`)
```css
:root {
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
  --card: 0 0% 100%;
  --card-foreground: 222.2 84% 4.9%;
  --popover: 0 0% 100%;
  --popover-foreground: 222.2 84% 4.9%;
  --primary: 222.2 47.4% 11.2%;
  --primary-foreground: 210 40% 98%;
  --secondary: 210 40% 96.1%;
  --secondary-foreground: 222.2 47.4% 11.2%;
  --muted: 210 40% 96.1%;
  --muted-foreground: 215.4 16.3% 46.9%;
  --accent: 210 40% 96.1%;
  --accent-foreground: 222.2 47.4% 11.2%;
  --destructive: 0 84.2% 60.2%;
  --destructive-foreground: 210 40% 98%;
  --border: 214.3 31.8% 91.4%;
  --input: 214.3 31.8% 91.4%;
  --ring: 222.2 84% 4.9%;
  --radius: 0.5rem;
}

.dark {
  --background: 222.2 84% 4.9%;
  --foreground: 210 40% 98%;
  --card: 222.2 84% 4.9%;
  --card-foreground: 210 40% 98%;
  --popover: 222.2 84% 4.9%;
  --popover-foreground: 210 40% 98%;
  --primary: 210 40% 98%;
  --primary-foreground: 222.2 47.4% 11.2%;
  --secondary: 217.2 32.6% 17.5%;
  --secondary-foreground: 210 40% 98%;
  --muted: 217.2 32.6% 17.5%;
  --muted-foreground: 215 20.2% 65.1%;
  --accent: 217.2 32.6% 17.5%;
  --accent-foreground: 210 40% 98%;
  --destructive: 0 62.8% 30.6%;
  --destructive-foreground: 210 40% 98%;
  --border: 217.2 32.6% 17.5%;
  --input: 217.2 32.6% 17.5%;
  --ring: 212.7 26.8% 83.9%;
}
```

### 3.2 常见 shadcn 风格类命名规范
- **按钮 (Buttons)**: `.btn`, `.btn-primary`, `.btn-secondary`, `.btn-outline`, `.btn-ghost`, `.btn-destructive`, `.btn-sm`, `.btn-lg`
- **卡片 (Card)**: `.card`, `.card-header`, `.card-title`, `.card-description`, `.card-content`, `.card-footer`
- **表单 (Input & Forms)**: `.input`, `.label`, `.select`, `.textarea`, `.checkbox`, `.switch`
- **反馈与提示 (Feedback)**: `.badge`, `.badge-secondary`, `.badge-destructive`, `.toast`, `.alert`
- **原生弹窗 (Dialog/Modal)**: 基于原生 HTML5 `<dialog class="dialog">`，配合 `dialog.showModal()` 与 `dialog.close()`。

---

## 4. Go 模板 (`html/template`) 与 SSR 最佳实践

### 4.1 模板定义与块继承 (Template Inheritance)
```html
<!-- layouts/base.html -->
{{ define "base" }}
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ .CSRFToken }}">
    <title>{{ block "title" . }}默认标题{{ end }} - 控制台</title>
    <link rel="stylesheet" href="/static/css/shadcn.css">
    {{ block "head" . }}{{ end }}
</head>
<body class="bg-background text-foreground antialiased min-h-screen flex flex-col">
    {{ template "navbar" . }}

    <main class="flex-1 container mx-auto px-4 py-6">
        {{ block "content" . }}{{ end }}
    </main>

    {{ template "footer" . }}
    <script src="/static/js/app.js"></script>
    {{ block "scripts" . }}{{ end }}
</body>
</html>
{{ end }}
```

### 4.2 自定义 FuncMap (常用辅助函数)
```go
var TemplateFuncs = template.FuncMap{
	// 格式化时间
	"formatDate": func(t time.Time) string {
		return t.Format("2006-01-02 15:04:05")
	},
	// 安全序列化 JSON 到前端 HTML 属性或 Script 中
	"toJSON": func(v any) template.JS {
		b, _ := json.Marshal(v)
		return template.JS(b)
	},
	// 权限检查
	"hasRole": func(userRole, targetRole string) bool {
		return userRole == targetRole || userRole == "admin"
	},
	// 字典辅助
	"dict": func(values ...any) (map[string]any, error) {
		if len(values)%2 != 0 {
			return nil, errors.New("invalid dict call")
		}
		dict := make(map[string]any, len(values)/2)
		for i := 0; i < len(values); i += 2 {
			key, ok := values[i].(string)
			if !ok {
				return nil, errors.New("dict keys must be strings")
			}
			dict[key] = values[i+1]
		}
		return dict, nil
	},
}
```

---

## 5. 现代原生 JavaScript 交互规范 (Vanilla JS Best Practices)

### 5.1 统一 Fetch API 封装（自动携带 CSRF 与错误捕获）
```javascript
// static/js/app.js
class APIClient {
    static getCSRFToken() {
        return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
    }

    static async request(url, options = {}) {
        const defaultHeaders = {
            'Content-Type': 'application/json',
            'X-CSRF-Token': this.getCSRFToken(),
        };

        const response = await fetch(url, {
            ...options,
            headers: { ...defaultHeaders, ...options.headers },
        });

        if (response.status === 401) {
            window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname);
            return;
        }

        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
            throw new Error(data.message || `Request failed with status ${response.status}`);
        }
        return data;
    }

    static get(url) { return this.request(url, { method: 'GET' }); }
    static post(url, body) { return this.request(url, { method: 'POST', body: JSON.stringify(body) }); }
    static delete(url) { return this.request(url, { method: 'DELETE' }); }
}
```

### 5.2 原生 `<dialog>` 模态框交互示例
```html
<button class="btn btn-primary" onclick="document.getElementById('user-dialog').showModal()">
    新建用户
</button>

<dialog id="user-dialog" class="dialog">
    <div class="dialog-content card">
        <div class="card-header">
            <h3 class="card-title">创建新用户</h3>
        </div>
        <form id="create-user-form" onsubmit="handleCreateUser(event)">
            <div class="card-content space-y-4">
                <div>
                    <label class="label">邮箱</label>
                    <input type="email" name="email" required class="input" />
                </div>
            </div>
            <div class="card-footer flex justify-end gap-2">
                <button type="button" class="btn btn-outline" onclick="this.closest('dialog').close()">取消</button>
                <button type="submit" class="btn btn-primary">保存</button>
            </div>
        </form>
    </div>
</dialog>

<script>
async function handleCreateUser(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const payload = Object.fromEntries(formData.entries());

    try {
        await APIClient.post('/api/v1/users', payload);
        Toast.success('用户创建成功');
        document.getElementById('user-dialog').close();
        window.location.reload();
    } catch (err) {
        Toast.error(err.message);
    }
}
</script>
```

---

## 6. 认证、会话与安全防护体系 (Auth & Security)

### 6.1 安全 Session Cookie 规范
- **HttpOnly**: 必须开启（`HttpOnly = true`），防止通过 XSS 窃取 Cookie。
- **Secure**: 生产环境必须开启（`Secure = true`），强制仅通过 HTTPS 传输。
- **SameSite**: 推荐设置 `SameSite = http.SameSiteLaxMode`（平衡 CSRF 防御与跨站正常跳转）。

```go
func SetAuthCookie(w http.ResponseWriter, sessionToken string, isProd bool, maxAge int) {
	http.SetCookie(w, &http.Cookie{
		Name:     "session_token",
		Value:    sessionToken,
		Path:     "/",
		MaxAge:   maxAge,
		HttpOnly: true,
		Secure:   isProd,
		SameSite: http.SameSiteLaxMode,
	})
}
```

### 6.2 CSRF Token 双重防御 (Double Submit Cookie / Header Check)
所有修改状态的 HTTP 方法（`POST`, `PUT`, `PATCH`, `DELETE`）必须经过 CSRF 校验中间件：

```go
func CSRFMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 读请求直接放行
		if r.Method == http.MethodGet || r.Method == http.MethodHead || r.Method == http.MethodOptions {
			next.ServeHTTP(w, r)
			return
		}

		cookieToken, err := r.Cookie("csrf_token")
		if err != nil || cookieToken.Value == "" {
			http.Error(w, `{"error":"missing csrf cookie"}`, http.StatusForbidden)
			return
		}

		// 从 Header 或 Form 表单提取 Token
		headerToken := r.Header.Get("X-CSRF-Token")
		if headerToken == "" {
			headerToken = r.FormValue("csrf_token")
		}

		// 恒定时间比较防止时序攻击
		if subtle.ConstantTimeCompare([]byte(cookieToken.Value), []byte(headerToken)) != 1 {
			http.Error(w, `{"error":"invalid csrf token"}`, http.StatusForbidden)
			return
		}

		next.ServeHTTP(w, r)
	})
}
```

### 6.3 密码哈希与 RBAC 权限中间件
```go
// 1. 密码安全哈希
func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	return string(bytes), err
}

func CheckPassword(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// 2. 角色鉴权中间件
func RequireRoles(roles ...string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			user, ok := r.Context().Value("user").(*User)
			if !ok || user == nil {
				http.Redirect(w, r, "/login", http.StatusSeeOther)
				return
			}

			hasPermission := false
			for _, role := range roles {
				if user.Role == role {
					hasPermission = true
					break
				}
			}

			if !hasPermission {
				http.Error(w, "Forbidden: Insufficient Permissions", http.StatusForbidden)
				return
			}

			next.ServeHTTP(w, r)
		})
	}
}
```

### 6.4 关键安全响应头中间件 (Security Headers)
```go
func SecurityHeadersMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("X-XSS-Protection", "1; mode=block")
		w.Header().Set("Referrer-Policy", "strict-origin-when-cross-origin")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;")
		next.ServeHTTP(w, r)
	})
}
```
