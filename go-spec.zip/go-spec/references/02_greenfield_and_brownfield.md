# 02. 新建项目 (Greenfield) 与存量改造 (Brownfield) 标准 SOP

无论面对从零初始化的新仓库还是已有数万行代码的存量项目，大模型必须严格遵循本 SOP，确保系统的一致性、向后兼容性与稳定性。

---

## 1. 新建项目标准 SOP (Greenfield Scaffolding)

新建 Go 项目时，按照以下阶段逐步构建：

### 阶段 1：项目环境与依赖初始化
1. **创建模块与版本基线**：
   ```bash
   go mod init <module-path>
   # 指定现代 Go 版本（推荐 1.22+ 或 1.23+，以便使用更安全的 for-range 变量行为及增强的 HTTP 路由/slog）
   ```
2. **初始化核心工具链**：
   - 放置 `.golangci.yml`（代码静态检查基准，参考 [golangci.yml](../templates/golangci.yml)）。
   - 放置 `Makefile`（提供 `test`, `race`, `lint`, `build` 标准目标，参考 [Makefile](../templates/Makefile)）。
   - 配置 `.gitignore`（忽略二进制文件、`.env`、覆盖率报告 `.coverprofile`）。

### 阶段 2：自底向上的骨架生成流水线
生成代码时应严格遵守依赖倒置与自底向上的顺序：

```mermaid
sequenceDiagram
    participant D as 1. Domain Entities & Errors
    participant I as 2. Interfaces / Contracts
    participant U as 3. Use Cases / Services
    participant A as 4. Adapters (DB/HTTP/gRPC)
    participant M as 5. Main Wiring (Entrypoint)

    Note over D: 领域模型与基础错误类型
    D->>I: 定义调用方接口 (Repository/Client)
    I->>U: 实现业务用例逻辑并编写单元测试
    U->>A: 编写持久层与传输层具体实现
    A->>M: 在 main.go 显式组装依赖并启动服务
```

### 阶段 3：服务启动与优雅停机（生产级标准样板）
在 `cmd/<app>/main.go` 中，必须标配优雅停机（Graceful Shutdown）：

```go
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

func main() {
	// 1. 初始化结构化日志
	logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{
		Level: slog.LevelInfo,
	}))
	slog.SetDefault(logger)

	// 2. 初始化全局生命周期 Context
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	// 3. 构建应用组件 (Manual Dependency Injection)
	srv := &http.Server{
		Addr:         ":8080",
		Handler:      buildRouter(),
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	// 4. 在后台 Goroutine 中启动服务
	go func() {
		slog.Info("server is starting", "addr", srv.Addr)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			slog.Error("server fatal error", "error", err)
			os.Exit(1)
		}
	}()

	// 5. 阻塞等待退出信号
	<-ctx.Done()
	slog.Info("shutdown signal received, draining connections...")

	// 6. 优雅停机超时控制
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := srv.Shutdown(shutdownCtx); err != nil {
		slog.Error("server forced to shutdown", "error", err)
	}
	slog.Info("server exited cleanly")
}

func buildRouter() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz/live", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"UP"}`))
	})
	return mux
}
```

---

## 2. 存量项目改造 SOP (Brownfield Modification)

在修改已有项目时，大模型的首要原则是：**一致性优先（Consistency First），最小爆炸半径（Minimal Blast Radius）。**

### 步骤 1：代码库特征探测（Inspect Before Code）
在编写任何代码前，大模型必须执行静态扫描与特征提取：
1. **日志体系探测**：
   - 检查使用的是 `log/slog`、`uber-go/zap`、`rs/zerolog` 还是标准 `log`？
   - *规则*：**继承已有日志体系**，严禁在 `zap` 项目中新引入 `slog`，亦严禁在 `slog` 项目中引入 `zap`。
2. **错误处理风格探测**：
   - 检查是否使用了自定义 Error Struct、`pkg/errors` 还是标准库 `fmt.Errorf("%w")`？
3. **架构分层探测**：
   - 检查已有目录结构（是 MVC、Standard Layout 还是 DDD/Clean？）。
   - 寻找现有类似功能的实现（如新增一个 API 时，查看其他已有 API 的 Handler/Service/Repo 是如何编写与命名的）。
4. **测试框架探测**：
   - 检查测试代码是否使用 `testify`、`ginkgo`、`gomock` 还是纯标准库。

### 步骤 2：保持 API 向后兼容（Backward Compatibility）
当需要为已有的函数/结构体添加新参数或新能力时，**禁止直接修改已导出的公开函数签名**，必须使用以下两种方式之一：

#### 方式 A：函数式选项模式 (Functional Options Pattern)
适用于配置、客户端初始化或复杂构造场景：

```go
// 现有构造函数保持兼容
type Option func(*ClientConfig)

func WithTimeout(d time.Duration) Option {
	return func(c *ClientConfig) {
		c.Timeout = d
	}
}

func WithMaxRetries(retries int) Option {
	return func(c *ClientConfig) {
		c.MaxRetries = retries
	}
}

// 扩展后的构造函数支持可变 options
func NewClient(addr string, opts ...Option) *Client {
	cfg := &ClientConfig{
		Timeout:    5 * time.Second, // 保持旧默认行为
		MaxRetries: 3,
	}
	for _, opt := range opts {
		opt(cfg)
	}
	return &Client{addr: addr, cfg: cfg}
}
```

#### 方式 B：新增带 Context 或带扩展名的函数
若必须修改核心函数签名（例如为遗留函数添加 `context.Context`）：
```go
// 保留旧函数（内部委托），标记 Deprecated，确保外部调用方不编译报错
// Deprecated: Use DoSomethingWithContext instead.
func DoSomething(param string) error {
	return DoSomethingWithContext(context.Background(), param)
}

// 新增现代签名
func DoSomethingWithContext(ctx context.Context, param string) error {
	// 实现核心逻辑
	return nil
}
```

### 步骤 3：防回归验证流水线 (Regression Prevention)
修改完成后，必须按顺序执行以下验证动作：
1. **运行现有相关测试**：
   ```bash
   go test -v -run <ModifiedPackageOrTestName> ./...
   ```
2. **为新增/修改的代码补充表格驱动测试**。
3. **执行并发竞争检查**：
   ```bash
   go test -race ./...
   ```
4. **运行代码风格与 Linter 检查**：
   ```bash
   golangci-lint run
   ```
