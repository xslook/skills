# 01. Go 项目规模分级与目录结构规范

本规范指导大模型在不同业务复杂度下选择合适且符合 Go 惯例的项目结构。**严禁在简单项目中进行过度分层设计，亦严禁在复杂大型系统中采用无约束的扁平结构。**

---

## 1. 规模分级决策矩阵 (Scale Decision Matrix)

| 规模分类 | 代码行数 / 模块估算 | 适用场景 | 架构范式 |
| :--- | :--- | :--- | :--- |
| **Small (小型/工具)** | < 1,000 行 / 单一关注点 | 独立 CLI 工具、脚本工具、单一功能 SDK/库、技术验证原型 | **Root Main + Internal Layout (根入口与内部隔离结构)** |
| **Medium (中型/服务)** | 1,000 ~ 15,000 行 / 典型业务应用 | 单体后端 API、中型微服务、CRUD 业务系统、后台 Worker 服务 | **Standard Go Project Layout** (`cmd/`, `internal/`, `pkg/`) |
| **Large (大型/企业级)** | > 15,000 行 / 多领域复杂业务 | 核心业务交易系统、复杂单体 (Modular Monolith)、多团队协同微服务 | **Clean Architecture / Hexagonal / DDD 分层** |

---

## 2. 小型项目规范：Root Main + Internal Layout (根入口与内部隔离结构)

### 适用特征
- 单一关注点或小型 CLI/实用工具，生命周期轻量；
- **目录隔离核心原则**：除 `main.go` 作为唯一启动入口保留在根目录外，其余具体实现代码均尽量收敛放置在 `internal/` 目录下，利用 Go 编译器机制保护内部私有逻辑，同时保持根目录精简。

### 推荐目录结构
```text
my-cli/
├── go.mod
├── go.sum
├── main.go            # 唯一根入口：解析 CLI 参数、读取配置、初始化并调用 internal 业务
├── internal/          # 私有实现代码（除 main.go 外，其余文件均收敛至此）
│   ├── app/           # 核心业务执行器
│   │   ├── app.go
│   │   └── app_test.go
│   ├── config/        # 配置定义与解析
│   │   └── config.go
│   └── client/        # 外部交互客户端或底层辅助
│       ├── client.go
│       └── client_test.go
├── README.md
└── Makefile
```

### 规范要点
1. **根目录极简**：根目录仅放置 `main.go`、`go.mod`、`README.md` 与构建脚本。`main.go` 保持极薄，负责衔接命令行参数与 `internal/` 包。
2. **私有保护**：所有核心业务逻辑、配置加载、第三方适配均归入 `internal/` 对应子包（或 `internal/app`），防止外部模块误导入内部私有实现。
3. **测试就近放置**：各子模块单元测试直接与被测文件并列放置在 `internal/` 相应目录下。

---

## 3. 中型项目规范：Standard Go Project Layout

### 适用特征
- 标准的生产级 Web API、gRPC 服务或微服务；
- 明确区分对外入口、内部私有业务逻辑与可被外部引用的公共包。

### 推荐目录结构
```text
my-service/
├── cmd/
│   └── server/
│       └── main.go           # 应用启动入口（负责初始化依赖图与信号监听）
├── internal/                 # 私有代码（Go 编译器强制禁止外部模块导入）
│   ├── app/                  # 应用装配层（Server 启动、优雅关闭）
│   │   └── app.go
│   ├── config/               # 配置加载与校验
│   │   └── config.go
│   ├── handler/              # 传输层 / API 适配（HTTP/REST 或 gRPC Controller）
│   │   ├── user_handler.go
│   │   └── user_handler_test.go
│   ├── service/              # 业务用例与领域逻辑
│   │   ├── user_service.go
│   │   └── user_service_test.go
│   ├── repository/           # 数据持久层（DB / Redis / 外部 RPC 适配）
│   │   ├── user_repo.go
│   │   └── user_repo_test.go
│   └── model/                # 内部数据结构与实体定义
│       └── user.go
├── pkg/                      # 允许外部项目安全引用的公共库（非业务强相关）
│   └── httpx/                # 例：通用的 HTTP 封装工具
│       └── client.go
├── api/                      # API 协议描述文件（OpenAPI / Swagger / Proto）
│   └── proto/
│       └── v1/
│           └── user.proto
├── configs/                  # 配置文件模板（yaml / env）
│   └── config.example.yaml
├── scripts/                  # 部署、构建、迁移脚本
│   └── migrations/
│       └── 000001_init.up.sql
├── .golangci.yml
├── Dockerfile
├── Makefile
├── go.mod
└── go.sum
```

### 规范要点
1. **`cmd/` 保持极薄**：`main.go` 只做三件事：加载配置、初始化各层依赖（Manual DI）、启动服务并监听 OS 信号。严禁在 `main.go` 中编写复杂业务逻辑。
2. **`internal/` 保护私有实现**：所有核心业务逻辑必须放入 `internal/`，利用 Go 编译器特性阻止外部项目导入内部包。
3. **慎用 `pkg/`**：仅当代码**真正具备通用性、且设计用于被外部仓库导入**时才放入 `pkg/`；否则一律放入 `internal/`。

---

## 4. 大型项目规范：Clean / Hexagonal / DDD 架构

### 适用特征
- 业务逻辑极其复杂，生命周期长，需与具体持久化框架（GORM/sqlc）和传输协议（HTTP/gRPC）高度解耦；
- 遵循依赖倒置原则（Dependency Inversion Principle）：**核心业务领域不依赖任何外部框架或基础设施**。

### 推荐目录结构
```text
enterprise-service/
├── cmd/
│   └── enterprise-server/
│       └── main.go
├── internal/
│   ├── domain/               # [核心领域层] 纯业务实体与领域接口（零外部第三方依赖）
│   │   ├── order/
│   │   │   ├── entity.go     # 领域实体与聚合根（包含业务不变式校验）
│   │   │   ├── value_objects.go
│   │   │   ├── repository.go # 仓储接口（由 Domain 定义，由 Infrastructure 实现）
│   │   │   └── events.go     # 领域事件定义
│   │   └── customer/
│   ├── usecase/              # [应用用例层] 业务流程编排、事务边界
│   │   ├── order/
│   │   │   ├── create_order.go
│   │   │   ├── create_order_test.go
│   │   │   └── query_order.go
│   ├── adapter/              # [适配器层] 输入/输出适配
│   │   ├── inbound/          # 输入适配器（Driver / Primary Adapters）
│   │   │   ├── http/         # REST API 路由与 Controller
│   │   │   │   ├── router.go
│   │   │   │   └── order_controller.go
│   │   │   ├── grpc/         # gRPC 服务端实现
│   │   │   └── event_sub/    # 消息队列消费者（Kafka / RabbitMQ）
│   │   └── outbound/         # 输出适配器（Driven / Secondary Adapters）
│   │       ├── repository/   # 仓储具体实现（Postgres / MySQL / sqlc）
│   │       │   └── order_pg_repo.go
│   │       ├── cache/        # 缓存适配（Redis）
│   │       │   └── order_redis.go
│   │       └── event_pub/    # 消息发布者
│   └── infrastructure/       # [基础设施层] 数据库连接池、日志、遥测组件初始化
│       ├── database/
│       ├── telemetry/
│       └── config/
├── api/
├── deployments/
├── Makefile
├── go.mod
└── go.sum
```

### 依赖流向规则（铁律）
```text
Inbound Adapters (HTTP/gRPC) ──> Use Cases ──> Domain (Entities)
                                     │
                                     └──> Outbound Interfaces (Defined in Domain/UseCase)
                                                ▲
                                                │ (Implements)
                                  Outbound Adapters (Postgres/Redis)
```
- **Domain 层**不得 import 任何 `adapter` 或外部框架（如 `gin`, `gorm`, `sqlx`）。
- 外部输入（HTTP Request）必须转换为 UseCase 的 DTO，经领域逻辑处理后，由 UseCase 返回 DTO，由 Controller 转换为 HTTP Response。

---

## 5. 多模块工作区规范 (Go Workspaces)

在多服务或微服务 monorepo 中，采用 Go 1.18+ 的 `go.work` 进行管理：
```text
monorepo/
├── go.work
├── go.work.sum
├── services/
│   ├── order-service/        # 独立的 go.mod
│   │   ├── go.mod
│   │   └── cmd/
│   └── user-service/         # 独立的 go.mod
│       ├── go.mod
│       └── cmd/
└── shared/
    └── contracts/            # 共享的 Proto/DTO 模块
        └── go.mod
```

### `go.work` 示例
```go
go 1.23.0

use (
    ./services/order-service
    ./services/user-service
    ./shared/contracts
)
```
