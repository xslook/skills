# 05. 错误处理与并发安全规范 (Errors & Concurrency)

Go 语言将错误与并发显式暴露给开发者。大模型在生成与重构代码时，必须严格贯彻 Go 现代错误链与生命周期受控的并发模式。

---

## 1. 现代错误处理规范 (Modern Error Handling)

### 1.1 错误包装与根因保留 (`%w`)
- 凡是在中间层向上抛出错误时，**必须使用 `%w` 进行包装**，以保留底层调用栈的根因链。
- 格式规范：`fmt.Errorf("<action> <context_identifier>: %w", ..., err)`。
- 严禁使用 `%v` 或 `%s` 格式化 `err`（会导致丢失类型信息，破坏 `errors.Is/As`）。

```go
// ✅ 正确：包含操作意图与主体标识，并包装错误
if err := r.db.ExecContext(ctx, query, orderID).Error; err != nil {
    return fmt.Errorf("execute update order status %s: %w", orderID, err)
}

// ❌ 错误：丢失根因链，无法溯源
if err != nil {
    return fmt.Errorf("db error: %v", err)
}
```

### 1.2 错误判定：`errors.Is` 与 `errors.As`
- **严禁**使用 `err == ErrNotFound` 进行哨兵错误比对（无法穿透包装后的 `%w`）。
- **严禁**使用 `strings.Contains(err.Error(), "not found")` 判断错误类型。

```go
// 1. 哨兵错误判定 (Sentinel Errors)
var ErrNotFound = errors.New("resource not found")

if errors.Is(err, ErrNotFound) {
    // 命中 404 分支
}

// 2. 自定义结构体错误提取 (Custom Error Types)
type ValidationError struct {
    Field string
    Rule  string
}

func (e *ValidationError) Error() string {
    return fmt.Sprintf("field %s failed on rule %s", e.Field, e.Rule)
}

var valErr *ValidationError
if errors.As(err, &valErr) {
    slog.WarnContext(ctx, "invalid input", "field", valErr.Field)
}
```

### 1.3 生产级业务错误定义 (Domain Error Pattern)
```go
package apperrors

import (
	"errors"
	"fmt"
	"net/http"
)

type ErrorCode string

const (
	CodeNotFound      ErrorCode = "NOT_FOUND"
	CodeInvalidArg    ErrorCode = "INVALID_ARGUMENT"
	CodeUnauthorized  ErrorCode = "UNAUTHORIZED"
	CodeInternalError ErrorCode = "INTERNAL_SERVER_ERROR"
)

type AppError struct {
	Code       ErrorCode
	Message    string
	HTTPStatus int
	Err        error
}

func (e *AppError) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("[%s] %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("[%s] %s", e.Code, e.Message)
}

func (e *AppError) Unwrap() error {
	return e.Err
}

func NewNotFoundError(message string, originalErr error) *AppError {
	return &AppError{
		Code:       CodeNotFound,
		Message:    message,
		HTTPStatus: http.StatusNotFound,
		Err:        originalErr,
	}
}
```

---

## 2. 并发与生命周期安全 (Concurrency & Goroutines)

### 2.1 铁律：严禁孤儿 Goroutine (No Orphan Goroutines)
任何启动 `go func()` 的地方，必须有以下退出保障之一：
1. 由父级 `context.Context` 的 `<-ctx.Done()` 触发安全退出；
2. 由 `sync.WaitGroup` 或 `errgroup.Group` 跟踪等待；
3. 为短期工作且在当前请求结束前通过通道保证必定返回。

### 2.2 推荐模式：使用 `errgroup` 管理并行任务
在聚合接口、批量处理或并行网络调用中，推荐使用 `golang.org/x/sync/errgroup`：

```go
package service

import (
	"context"
	"golang.org/x/sync/errgroup"
)

type AggregatedData struct {
	UserProfile  *Profile
	OrderHistory []*Order
}

func (s *AggregatorService) FetchDashboard(ctx context.Context, userID string) (*AggregatedData, error) {
	// 创建绑定 Context 的 errgroup，任一任务返回 error 则取消所有未完成的任务
	g, ctx := errgroup.WithContext(ctx)

	var (
		profile *Profile
		orders  []*Order
	)

	// 并行任务 1: 查询用户信息
	g.Go(func() error {
		p, err := s.userClient.GetProfile(ctx, userID)
		if err != nil {
			return fmt.Errorf("fetch profile for user %s: %w", userID, err)
		}
		profile = p
		return nil
	})

	// 并行任务 2: 查询订单历史
	g.Go(func() error {
		o, err := s.orderClient.ListOrders(ctx, userID)
		if err != nil {
			return fmt.Errorf("fetch orders for user %s: %w", userID, err)
		}
		orders = o
		return nil
	})

	// 阻塞等待全部完成
	if err := g.Wait(); err != nil {
		return nil, err
	}

	return &AggregatedData{
		UserProfile:  profile,
		OrderHistory: orders,
	}, nil
}
```

### 2.3 Goroutine 内部 Panic 捕获机制
后台独立运行的工作 Goroutine（Worker / Consumer）必须在入口处挂载 `defer recover()`，防止单次数据异常导致整个服务进程 Panic 崩溃：

```go
func StartWorker(ctx context.Context, jobQueue <-chan Job) {
	go func() {
		defer func() {
			if r := recover(); r != nil {
				slog.Error("worker recovered from unexpected panic",
					slog.Any("panic_value", r),
					slog.String("stack", string(debug.Stack())),
				)
			}
		}()

		for {
			select {
			case <-ctx.Done():
				slog.Info("worker gracefully stopped by context")
				return
			case job, ok := <-jobQueue:
				if !ok {
					slog.Info("job queue channel closed, worker exiting")
					return
				}
				processJob(job)
			}
		}
	}()
}
```

### 2.4 Channel 所有权准则 (Channel Ownership)
1. **谁创建，谁负责关闭**：只有创建 Channel 的 Goroutine 才有权调用 `close(ch)`。
2. **接收方切勿调用 `close`**；发送方切勿在已关闭的 Channel 上继续写入（会导致 panic）。
3. 纯通知类信号使用 `chan struct{}`，传递数据使用有具体类型的 Channel。
