# 03. 日志与可观测性规范 (Logging & Observability)

本规范定义生产级 Go 系统的可观测性标准。默认采用 Go 1.21+ 官方标准库 `log/slog` 与 OpenTelemetry 标准。

---

## 1. 结构化日志规范 (`log/slog`)

### 1.1 核心原则
1. **全结构化（Structured Only）**：严禁在日志中拼接无结构的文本（如 `fmt.Sprintf` 后打日志），必须使用 Key-Value 属性（`slog.Attr` 或 key-value 对）。
2. **Context 传递（Context Aware）**：凡有 `ctx` 的函数，必须调用 `slog.InfoContext(ctx, ...)`、`slog.ErrorContext(ctx, ...)`，以便中间件或 Handler 自动提取链路 ID（`trace_id`, `span_id`, `request_id`）。
3. **日志级别语义**：
   - `DEBUG`: 诊断性细节，通常仅在本地或测试环境开启。
   - `INFO`: 系统关键节点与生命周期（如服务启动、监听端口、批处理任务完成）。
   - `WARN`: 可容错的异常分支、降级处理、即将废弃的调用或非致命的外部依赖抖动。
   - `ERROR`: 需研发介入的故障、未捕获的错误、中断业务流程的操作。

### 1.2 上下文链路 ID 自动注入 Handler
通过自定义 `slog.Handler` 包装层，自动从 `context.Context` 中提取 TraceID：

```go
package logger

import (
	"context"
	"log/slog"
)

type contextKey string

const (
	TraceIDKey   contextKey = "trace_id"
	RequestIDKey contextKey = "request_id"
)

type ContextHandler struct {
	slog.Handler
}

func (h *ContextHandler) Handle(ctx context.Context, r slog.Record) error {
	if ctx != nil {
		if traceID, ok := ctx.Value(TraceIDKey).(string); ok && traceID != "" {
			r.AddAttrs(slog.String("trace_id", traceID))
		}
		if reqID, ok := ctx.Value(RequestIDKey).(string); ok && reqID != "" {
			r.AddAttrs(slog.String("request_id", reqID))
		}
	}
	return h.Handler.Handle(ctx, r)
}
```

### 1.3 日志书写好坏对比 (Good vs Bad)

#### ❌ 错误示范 (Anti-Patterns)
```go
// 错误 1: 无结构化字符串拼接
slog.Info(fmt.Sprintf("user %d created order %s with amount %f", userID, orderID, amount))

// 错误 2: 丢失 Context 导致无法串联链路
slog.Error("failed to query database", "err", err)

// 错误 3: 既打印日志又向上返回错误 (Log & Return)
if err := repo.Save(ctx, order); err != nil {
    slog.ErrorContext(ctx, "failed to save order", "error", err) // 导致上层重复打日志，日志风暴
    return fmt.Errorf("save order: %w", err)
}

// 错误 4: 泄露敏感信息
slog.InfoContext(ctx, "user login", "username", u, "password", pwd, "token", jwtToken)
```

#### ✅ 正确示范 (Best Practices)
```go
// 正确 1: 强类型结构化键值对
slog.InfoContext(ctx, "order created successfully",
    slog.Int64("user_id", userID),
    slog.String("order_id", orderID),
    slog.Float64("amount", amount),
)

// 正确 2: 错误只处理一次（在最顶层 Handler 打印）
if err := svc.CreateOrder(ctx, req); err != nil {
    // Controller/Handler 层作为边界，统一记录包含上下文的 ERROR 日志并返回 HTTP 状态码
    slog.ErrorContext(ctx, "failed to handle create_order request",
        slog.Any("error", err),
        slog.String("order_id", req.OrderID),
    )
    http.Error(w, "internal server error", http.StatusInternalServerError)
    return
}
```

---

## 2. 指标监控规范 (Metrics & RED Method)

所有微服务与对外接口必须遵循 **RED 方法** 暴露指标：
- **R (Rate)**: 每秒请求数（Request Throughput）。
- **E (Errors)**: 每秒错误数（Error Rate）。
- **D (Duration)**: 请求耗时直方图（Latency Distribution / P90, P99）。

### Prometheus 中间件标准实现示例
```go
package telemetry

import (
	"net/http"
	"strconv"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	httpRequestsTotal = promauto.NewCounterVec(
		prometheus.CounterOpts{
			Name: "http_requests_total",
			Help: "Total number of HTTP requests processed.",
		},
		[]string{"method", "path", "status"},
	)

	httpRequestDuration = promauto.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "http_request_duration_seconds",
			Help:    "Histogram of response latency (seconds) for HTTP requests.",
			Buckets: prometheus.DefBuckets, // [.005, .01, .025, .05, .1, .25, .5, 1, 2.5, 5, 10]
		},
		[]string{"method", "path"},
	)
)

type statusRecorder struct {
	http.ResponseWriter
	statusCode int
}

func (rec *statusRecorder) WriteHeader(code int) {
	rec.statusCode = code
	rec.ResponseWriter.WriteHeader(code)
}

func MetricsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w, statusCode: http.StatusOK}

		next.ServeHTTP(rec, r)

		duration := time.Since(start).Seconds()
		path := r.URL.Path // 生产建议替换为路由模版如 "/users/{id}"

		httpRequestsTotal.WithLabelValues(r.Method, path, strconv.Itoa(rec.statusCode)).Inc()
		httpRequestDuration.WithLabelValues(r.Method, path).Observe(duration)
	})
}
```

---

## 3. 链路追踪 (Distributed Tracing / OpenTelemetry)

> [!NOTE]
> **规模适用性原则**：在**小型和中型项目**中，**不强制要求**引入分布式链路追踪（OpenTelemetry / Jaeger），除非业务明确要求跨多服务排查或有特殊架构说明。
> 中小型项目应聚焦于结构化日志（`slog` 配合全局传递的 `trace_id` / `request_id`）与基础 RED 指标，避免过早引入复杂的外部追踪 Agent 与 Collector。大型微服务系统则必须遵循以下追踪规范。

### OpenTelemetry Span 创建与传递 (适用于大型/分布式系统)
```go
package service

import (
	"context"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
)

var tracer = otel.Tracer("order-service")

func (s *OrderService) ProcessOrder(ctx context.Context, orderID string) (err error) {
	// 创建 Span
	ctx, span := tracer.Start(ctx, "OrderService.ProcessOrder")
	defer func() {
		if err != nil {
			span.RecordError(err)
			span.SetStatus(codes.Error, err.Error())
		}
		span.End()
	}()

	span.SetAttributes(attribute.String("order.id", orderID))

	// 下游调用透传 ctx
	return s.repo.UpdateOrderStatus(ctx, orderID, "PROCESSING")
}
```

---

## 4. 健康检查与探针规范 (Health Probes)

云原生/K8s 环境下必须拆分以下两个端点：

1. **存活探针 (`GET /healthz/live` - Liveness Probe)**:
   - 目标：检测进程是否存活、是否发生死锁。
   - 行为：只要 HTTP Server 能响应即返回 `200 OK`，**严禁在此处检查数据库或外部依赖**（避免外部依赖抖动引起服务整体被 K8s 级联重启）。
2. **就绪探针 (`GET /healthz/ready` - Readiness Probe)**:
   - 目标：检测服务是否具备接收流量的能力。
   - 行为：探测核心下游依赖（数据库 Ping、Redis Ping、关键消息队列连接状态）。若失败返回 `503 Service Unavailable`。

```go
func RegisterHealthRoutes(mux *http.ServeMux, db *sql.DB, rdb *redis.Client) {
	// Liveness
	mux.HandleFunc("GET /healthz/live", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"alive"}`))
	})

	// Readiness
	mux.HandleFunc("GET /healthz/ready", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
		defer cancel()

		if err := db.PingContext(ctx); err != nil {
			http.Error(w, `{"status":"unready","reason":"database unreachable"}`, http.StatusServiceUnavailable)
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			http.Error(w, `{"status":"unready","reason":"redis unreachable"}`, http.StatusServiceUnavailable)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"ready"}`))
	})
}
```
