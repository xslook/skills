# 06. Go 惯用语法与陷阱防范 (Idiomatic Go & Pitfall Prevention)

本规范总结了符合 Go 语言哲学的代码设计惯例（Idiomatic Go）以及大模型在编写 Go 代码时必须规避的典型陷阱。

---

## 1. 接口设计哲学 (Interface Design)

### 1.1 “接受接口，返回结构体” (Accept Interfaces, Return Structs)
- **函数入参**：尽可能接受满足需要的最小接口（增强解耦与可测性）。
- **函数出参**：优先返回具体的 Struct 指针或值（保留扩展能力，避免给调用方强加过早抽象）。

```go
// ✅ 正确：接收最小接口，返回具体类型
type Reader interface {
    Read(p []byte) (n int, err error)
}

func ParsePayload(r io.Reader) (*Payload, error) { ... }

// ❌ 错误：过早抽象，返回无意义的 interface
func NewUserService() UserServiceInterface { ... }
```

### 1.2 杜绝接口污染 (Avoid Interface Pollution)
- 不要为一个仅有单一实现的结构体在同一包中提前声明接口。
- 接口应当在**消费者（Consumer）**需要对其进行替换、Mock 或解耦时，由消费者侧按需声明。

### 1.3 零值可用 (Make Zero Values Useful)
设计 Struct 时，力求让其零值即可直接安全使用，而无需必须通过显式 Init 函数：
```go
// ✅ 正确：零值开箱即用（内嵌 sync.Mutex，切片无需显式 make）
type SafeCounter struct {
    mu    sync.Mutex
    count int
}

func (c *SafeCounter) Inc() {
    c.mu.Lock()
    defer c.mu.Unlock()
    c.count++
}
```

---

## 2. 命名与代码风格规范 (Naming Conventions)

### 2.1 专有名词大写 (Acronyms & Initialisms)
Go 惯例要求专有名词在标识符中保持全大写（或私有首字母小写）：
- **正确**：`userID`, `appURL`, `httpServer`, `parseJSON`, `xmlReader`, `ipAddress`
- **错误**：`userId`, `appUrl`, `HttpServer`, `parseJson`, `XmlReader`, `IpAddress`

### 2.2 避免包名口吃 (Avoid Stuttering)
- **正确**：`user.Service`, `http.Client`, `config.Loader`, `db.Connection`
- **错误**：`user.UserService`, `http.HttpClient`, `config.ConfigLoader`, `db.DBConnection`

### 2.3 包名命名规范
- 包名必须全部小写、单数形式、简短清晰、无下划线或连字符。
- 禁止命名垃圾桶包：`util`, `utils`, `common`, `helper`, `shared`。
  - *重构建议*：按具体功能命名为 `httpx`, `stringsutil`, `crypto`, `hash`。

---

## 3. 常见内存与资源泄漏陷阱 (Memory & Resource Traps)

### 3.1 HTTP Response Body 未关闭或未排空
```go
// ✅ 正确做法：无论如何必须排空并关闭 Body
resp, err := client.Do(req)
if err != nil {
    return err
}
defer func() {
    io.Copy(io.Discard, resp.Body) // 排空以支持 TCP 连接复用
    resp.Body.Close()
}()
```

### 3.2 SQL Rows 未关闭
```go
// ✅ 正确做法：必须 defer rows.Close() 并在结束时检查 rows.Err()
rows, err := db.QueryContext(ctx, "SELECT id, name FROM users WHERE age > $1", age)
if err != nil {
    return err
}
defer rows.Close()

for rows.Next() {
    if err := rows.Scan(&id, &name); err != nil {
        return err
    }
}
if err := rows.Err(); err != nil {
    return fmt.Errorf("iterate rows: %w", err)
}
```

### 3.3 循环中的 `defer` 资源悬挂
在长循环中调用 `defer` 会导致所有资源直到外层函数退出时才释放，极易打满文件句柄或内存：

```go
// ❌ 错误：长循环中 defer 导致内存/句柄暴涨
for _, filename := range files {
    f, _ := os.Open(filename)
    defer f.Close() // 只有在循环所在的外层函数返回时才会执行！
    process(f)
}

// ✅ 正确：通过匿名函数控制 defer 作用域
for _, filename := range files {
    func(name string) {
        f, err := os.Open(name)
        if err != nil {
            return
        }
        defer f.Close() // 每次循环结束立即释放
        process(f)
    }(filename)
}
```

### 3.4 切片重切片导致底层大数组无法回收 (Subslice Memory Holding)
当从一个超大切片中截取少量数据并长期保留时，原底层大数组将无法被 GC 回收：

```go
// ❌ 错误：虽然只需要 10 字节，但 100MB 底层数组依然常驻内存
func GetHeader(hugeData []byte) []byte {
    return hugeData[:10]
}

// ✅ 正确：通过 copy 创建独立内存
func GetHeader(hugeData []byte) []byte {
    header := make([]byte, 10)
    copy(header, hugeData[:10])
    return header
}
```

---

## 4. 依赖注入与构造器规范 (Manual Dependency Injection)

在 Go 中，推荐优先采用**显式构造函数传递依赖（Manual DI）**，保持依赖图透明可追溯：

```go
package app

type App struct {
    userHandler  *handler.UserHandler
    orderHandler *handler.OrderHandler
}

func NewApp(db *sql.DB, rdb *redis.Client, logger *slog.Logger) *App {
    // 1. 初始化仓储层
    userRepo := repository.NewUserPostgres(db)
    orderRepo := repository.NewOrderPostgres(db)

    // 2. 初始化服务层
    userService := service.NewUserService(userRepo, logger)
    orderService := service.NewOrderService(orderRepo, userRepo, logger)

    // 3. 初始化 Handler 层
    userHandler := handler.NewUserHandler(userService)
    orderHandler := handler.NewOrderHandler(orderService)

    return &App{
        userHandler:  userHandler,
        orderHandler: orderHandler,
    }
}
```
