# 04. 测试规范与质量门禁 (Testing & Quality Gates)

高质量的自动化测试是 Go 代码稳定性的基石。本规范规定了单元测试、表格驱动测试、Mock 原则与质量验证流程。

---

## 1. 表格驱动测试标准 (Table-Driven Tests)

在 Go 中，所有包含分支逻辑的函数必须使用**表格驱动测试（Table-Driven Tests）**。

### 标准测试模板
```go
package service_test

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestUserService_Register(t *testing.T) {
	t.Parallel() // 启用测试并行运行

	// 定义测试入参和期望
	type args struct {
		email    string
		password string
	}

	tests := []struct {
		name       string
		args       args
		setupMocks func(m *MockUserRepo)
		wantUserID string
		wantErr    error
		checkErr   func(t *testing.T, err error) // 适用于动态错误断言
	}{
		{
			name: "成功注册用户",
			args: args{
				email:    "user@example.com",
				password: "SecurePassword123!",
			},
			setupMocks: func(m *MockUserRepo) {
				m.EXPECT().
					FindByEmail(context.Background(), "user@example.com").
					Return(nil, ErrUserNotFound)
				m.EXPECT().
					Create(context.Background(), mock.Anything).
					Return("usr-1001", nil)
			},
			wantUserID: "usr-1001",
			wantErr:    nil,
		},
		{
			name: "邮箱已被注册",
			args: args{
				email:    "existing@example.com",
				password: "SecurePassword123!",
			},
			setupMocks: func(m *MockUserRepo) {
				m.EXPECT().
					FindByEmail(context.Background(), "existing@example.com").
					Return(&User{ID: "usr-0001"}, nil)
			},
			wantUserID: "",
			wantErr:    ErrEmailAlreadyExists,
		},
	}

	for _, tt := range tests {
		tt := tt // 兼容旧版本 Go 闭包变量捕获（Go 1.22+ 已自动安全）
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			// 1. 初始化 Mock 与待测对象
			mockRepo := NewMockUserRepo(t)
			if tt.setupMocks != nil {
				tt.setupMocks(mockRepo)
			}
			svc := NewUserService(mockRepo)

			// 2. 执行目标方法
			gotID, err := svc.Register(context.Background(), tt.args.email, tt.args.password)

			// 3. 校验错误
			if tt.wantErr != nil {
				require.Error(t, err)
				assert.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)

			// 4. 校验返回值
			assert.Equal(t, tt.wantUserID, gotID)
		})
	}
}
```

---

## 2. 断言规则：`assert` vs `require`

在引入 `testify` 时，严格区分使用场景：
- **`require.*`**：用于前置条件校验。当失败时会立即调用 `t.FailNow()` 终止当前测试，防止发生空指针解引用引发 `panic`（如 `require.NoError(t, err)`、`require.NotNil(t, result)`）。
- **`assert.*`**：用于结果比对。失败时仅标记测试失败，继续执行后续断言，以便一次性收集所有断言失败信息（如 `assert.Equal(t, want, got)`）。

---

## 3. Mock 原则与接口设计

1. **不要 Mock 你不拥有的接口（Don't Mock What You Don't Own）**：
   - 不要去 Mock 标准库（如 `http.Client`）或第三方库底层结构；应通过定义自己的业务适配接口（如 `PaymentGateway`），只 Mock 自己的接口。
2. **消费者定义接口（Consumer-Driven Interfaces）**：
   ```go
   // ❌ 错误：在持久层包中定义了 20 个方法的巨大接口
   package postgres
   type GlobalUserStore interface { ... }

   // ✅ 正确：在需要用到的 Service 包中，只定义本 Service 需要的 2 个方法
   package service
   type UserFinder interface {
       FindByID(ctx context.Context, id string) (*User, error)
   }
   ```
3. **优先纯内存 Fake / 内存数据库**：
   - 简单的状态存储优先使用 Fake（基于 `sync.Map` 或 slice 实现），减少庞大的 Mock 样板代码。

---

## 4. 模糊测试 (Fuzzing)

对于所有涉及数据序列化/反序列化、字符串解析、加密解密、协议编解码的函数，必须配备 Fuzz 测试：

```go
func FuzzParseJSONConfig(f *testing.F) {
	// 1. 添加种子语料库 (Seed Corpus)
	f.Add([]byte(`{"host":"localhost","port":8080}`))
	f.Add([]byte(`{}`))
	f.Add([]byte(`invalid json`))

	f.Fuzz(func(t *testing.T, data []byte) {
		cfg, err := ParseConfig(data)
		if err != nil {
			// 能够正常返回 error 即可，绝对不能 panic
			return
		}
		// 若解析成功，基础字段不得处于不可用非法状态
		if cfg == nil {
			t.Errorf("expected non-nil config when err is nil")
		}
	})
}
```

---

## 5. 质量门禁与验证命令 (Quality Gates)

在 CI 或本地提交前，必须通过以下 4 项质量检查：

```bash
# 1. 运行并发数据竞争检测（核心必跑项）
go test -race -timeout 60s ./...

# 2. 运行单元测试并统计覆盖率
go test -coverprofile=coverage.out -covermode=atomic ./...
go tool cover -func=coverage.out | grep total

# 3. 运行静态代码检查
golangci-lint run --timeout=5m

# 4. 检查依赖安全性与整洁度
go mod tidy
go mod verify
```
