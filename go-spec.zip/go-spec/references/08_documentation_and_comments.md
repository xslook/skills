# 08. 代码注释与文档规范 (Documentation & Code Comments)

本规范遵循 Go 官方文档标准（[Effective Go - Commentary](https://go.dev/doc/effective_go#commentary)、[Go Code Review Comments](https://go.dev/wiki/CodeReviewComments#comment-sentences)、[Go Doc Comments](https://go.dev/doc/comment)），明确大模型在编写 Go 代码时的注释深度、结构与规范要求。

---

## 1. 核心不可违背原则 (Core Comment Principles)

1. **导出标识符 100% 注释覆盖**：
   - 每一个**对外导出的包（Package）、结构体（Struct）、接口（Interface）、函数（Function）、方法（Method）、常量（Const）与变量（Var）**，都必须有规范的 GoDoc 注释。
2. **标识符名称开头（Comment Sentences）**：
   - 声明的文档注释必须是**完整句子**，且**必须以被声明的标识符名称开头**（即使读起来稍显重复，也是 GoDoc 的强制格式标准）。
3. **关键/核心函数必须包含使用示例（Examples Required）**：
   - 对于核心业务用例（UseCase）、底层通用算法、对外公开 SDK/API 函数，注释中必须包含典型调用示例代码或配有 `ExampleXxx` 测试。
4. **代码块内部注重说明“为什么”（Explain "Why", Not Just "What"）**：
   - 代码块内部的行级注释，**严禁机械复述代码字面做了什么**（如 `// i 加 1`），必须阐释背后的**设计意图、业务背景、并发安全理由、边界防御假设或特殊折衷（Trade-offs）**。

---

## 2. 导出标识符注释标准 (GoDoc Commentary Standard)

### 2.1 包注释 (Package Comments)
每个包必须在包声明前包含一段概述注释。多文件包通常将包注释集中写在独立的 `doc.go` 或包含主逻辑的根文件中：

```go
// Package auth 提供基于 JWT 与安全 Cookie 的身份认证、会话管理及 RBAC 角色授权机制。
//
// 该包默认遵循 OWASP 安全规范，所有会话 Cookie 均采用 HttpOnly 与 SameSite 保护。
package auth
```

### 2.2 结构体与接口注释 (Types & Interfaces)
```go
// OrderManager 负责订单的完整生命周期管理，包括订单创建、支付状态流转与库存扣减编排。
// 并发安全，允许多个 Goroutine 共享同一实例。
type OrderManager struct {
	repo   OrderRepository
	logger *slog.Logger
}

// PaymentGateway 定义与外部第三方支付渠道（如微信、支付宝、Stripe）交互的标准契约。
// 所有方法实现均需保证幂等性，并支持通过 ctx 传播超时与取消信号。
type PaymentGateway interface {
	// Pay 发起单笔支付扣款操作。
	// 若支付已被处理，需返回包含既有交易号的支付结果而非重复扣款。
	Pay(ctx context.Context, req *PaymentRequest) (*PaymentResult, error)
}
```

### 2.3 普通导出函数/方法注释
```go
// CalculateTax 根据用户所在地区与订单明细计算应缴税费。
// 若地区未配置税率表，将默认回退至国家法定基础税率。
func (m *OrderManager) CalculateTax(region string, items []Item) (decimal.Decimal, error) {
    ...
}
```

---

## 3. 关键/核心函数的示例规范 (Examples for Critical Functions)

对于核心业务函数、通用公共库函数以及易混淆的 API，注释中必须通过缩进块（在 Go 1.19+ 中可使用空行+缩进）提供直观的**使用示例（Usage Example）**：

### 规范示例
```go
// BatchRetry 以指定的重试策略和指数退避时间执行给定的闭包任务。
//
// 当任务返回不可恢复错误（如 ValidationError）时，重试将立即中断并返回根因；
// 当任务在最大重试次数内成功，或返回可重试错误达到上限时，返回最终执行结果。
//
// 示例用法:
//
//	policy := RetryPolicy{
//	    MaxAttempts: 3,
//	    InitialBackoff: 100 * time.Millisecond,
//	}
//	err := BatchRetry(ctx, policy, func(ctx context.Context) error {
//	    return client.SyncData(ctx)
//	})
//	if err != nil {
//	    slog.Error("batch retry failed", "err", err)
//	}
func BatchRetry(ctx context.Context, policy RetryPolicy, fn func(ctx context.Context) error) error {
    ...
}
```

> [!TIP]
> **可执行测试示例 (Executable Examples)**：对于 `pkg/` 下的通用库，推荐在 `_test.go` 中编写 `func ExampleBatchRetry()`，GoDoc 会自动将其提取并渲染为可交互运行的文档示例。

---

## 4. 代码块内部关键处注释：“为什么”而非“做什么” (Explain "Why")

在函数内部，良好的注释解释的是**约束、设计权衡、非直观逻辑与防御意图**：

### ❌ 错误示范：冗余废话（仅解释“做什么”）
```go
// 加锁
mu.Lock()
// 解锁
defer mu.Unlock()

// 如果 users 为空则返回错误
if len(users) == 0 {
    return errors.New("empty users")
}

// 遍历 users 切片
for _, u := range users {
    // 打印日志
    slog.Info("processing", "user", u.ID)
}
```

### ✅ 正确示范：深刻揭示“为什么”（Intent & Invariants）
```go
// 必须在复制状态前获取读锁，防止与后台定期轮询的刷新 Goroutine 产生数据竞争（Data Race）。
mu.RLock()
snapshot := make([]TargetNode, len(nodes))
copy(snapshot, nodes)
mu.RUnlock()

// 业务前置断言：空批次不允许透传给底层批处理存储引擎，
// 否则底层数据库驱动会因空 VALUES 语句抛出难以排查的语法错误。
if len(users) == 0 {
    return apperrors.NewInvalidArg("users slice cannot be empty")
}

// 注意：此处采用带缓冲通道（Buffer Size = 100）而非无缓冲通道，
// 目的在于吸收瞬间突发的外部 Webhook 流量波峰，避免在下游 Worker 短暂 GC 时阻塞 HTTP 连接。
taskQueue := make(chan Task, 100)

// 针对 macOS / Linux 早期内核版本的文件描述符重用缺陷实施防御性补偿，
// 强制先休眠 5ms 确保底层 TCP 句柄完全从 TIME_WAIT 状态解挂。
time.Sleep(5 * time.Millisecond)
```

---

## 5. 特殊场景标记规范 (Standard Directives & Tags)

在代码存在废弃、临时妥协或已知隐患时，必须使用统一的标准标识符：

### 5.1 废弃声明 (`Deprecated:`)
Go 官方 Linter 与 IDE 会识别以 `// Deprecated:` 开头的注释并发出警示。必须指明替代方案：
```go
// QueryUserByID 查询用户基础信息。
//
// Deprecated: 该方法不支持租户隔离，请迁移使用具备多租户与 Context 穿透的 [QueryUserByIDWithTenant]。
func QueryUserByID(id string) (*User, error) {
    ...
}
```

### 5.2 待办与缺陷说明 (`TODO` & `BUG`)
- 格式：`// TODO(<责任人或Issue>): <具体行动项与预期解决场景>`
- 严禁出现无归属、无上下文的裸 `// TODO`。
```go
// TODO(developer): 待对接统一分布式限流中心后，将本地 Token Bucket 替换为 Redis Sliding Window 限流器 (Issue #142)
if !limiter.Allow() {
    return ErrRateLimited
}

// BUG(developer): 在 Windows 平台下，当路径包含中文或特殊字符时，底层系统调用可能截断长路径。
```

---

## 6. 代码注释自查清单 (Comments Self-Checklist)

在生成或交付代码前，必须进行以下自查：
- [ ] 所有导出的包、类型、函数、常量均有注释，且注释第一句以标识符名称开头。
- [ ] 核心业务方法与复杂公共函数，均附带了清晰的入参与调用示例。
- [ ] 复杂的并发调度（Channel/Mutex/Goroutine）、底层系统调用或算法分支处，均有清晰解释“为什么这样写”的内部注释。
- [ ] 废弃接口均规范使用了 `// Deprecated:` 并给出了替代迁移路径。
- [ ] 无机械复述语法表象的无意义垃圾注释。
