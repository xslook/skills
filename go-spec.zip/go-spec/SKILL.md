---
name: go-spec
description: >-
  Go语言大模型开发与架构规范指南。涵盖从小脚本到大型微服务/DDD架构的目录设计、新建与存量项目改造SOP、Go 1.23+标准、log/slog结构化日志、可观测性、表格驱动测试、错误链与并发安全、现代原生Web页面处理(Go模板/shadcn纯CSS/单二进制embed/认证安全)、以及严格的GoDoc注释与代码意图说明规范。
---

# Go 语言工程与代码规范 Skill (Go LLM Specification)

本规范专为大模型（LLM）设计，用于指导 Go 语言代码生成、重构、审查、全栈 Web 页面开发与架构设计。本规范严格遵循 Go 官方最佳实践（Effective Go、Go Code Review Comments、Uber Go Style Guide）以及现代 Go（Go 1.23+）标准。

---

## 1. 核心不可违背铁律 (Non-Negotiable Golden Rules)

在任何 Go 语言开发任务中，必须无条件遵循以下铁律：

1. **显式错误处理与包装 (Explicit Errors & Wrapping)**:
   - 严禁忽略 `error`（除极少数标准库文档明确允许的情形外，必须显式检查）。
   - 向上返回错误必须使用 `fmt.Errorf("...: %w", err)` 保留根因；判断错误必须使用 `errors.Is` 和 `errors.As`，禁止对错误字符串做匹配。
   - **错误只处理一次**：要么就地处理并记录日志，要么向上返回并包装，严禁“既打日志又向上返回”。
2. **Context 全链路穿透 (Context Propagation)**:
   - 所有涉及 I/O、RPC、数据库、网络调用、长耗时计算或可能被取消的函数，首个参数必须为 `ctx context.Context`。
   - 严禁将 `context.Context` 存储在结构体字段中。
3. **Goroutine 生命周期闭环 (No Leaking Goroutines)**:
   - 严禁启动无停止机制的“孤儿” Goroutine。任何后台 Goroutine 必须由 `context.Done()` 监听退出，或由 `sync.WaitGroup` / `errgroup` 明确管理。
4. **小接口与接受接口/返回具体类型 (Accept Interfaces, Return Structs)**:
   - 接口应由**调用方（Consumer）**按需定义，保持最小化（1~2 个方法最佳），避免在实现包（Producer）中预先定义大而全的冗余接口。
5. **存量项目风格一致性优先 (Consistency First in Brownfield)**:
   - 在修改已有项目时，**必须优先探测并遵循项目已有的设计分层、日志库、错误体系与命名风格**，严禁强行引入冲突的第二套标准。
6. **Web 页面轻量与单二进制交付 (Modern Vanilla Web & Single Binary)**:
   - 在 Go 项目中开发 Web 页面时，优先采用现代原生 Web 标准（Vanilla JS/CSS/HTML5）与 Go `html/template`，样式对齐 **shadcn/ui** 纯 CSS 设计 Tokens，严禁无必要引入沉重的 Node.js/Webpack 构建工具链。
   - 模板与静态资源必须通过 `//go:embed` 打包进单一二进制可执行文件中。
   - 涉及会话与状态变更必须标配 `HttpOnly/Secure` Cookie、CSRF Token 防护与安全响应头。
7. **严格的 GoDoc 注释与代码意图说明 (GoDoc Comments & Intent Explanation)**:
   - 所有导出的包、类型、函数、方法、常量必须有 GoDoc 完整句子注释，且**第一句必须以被声明的标识符名称开头**。
   - 关键/核心函数必须在注释中提供使用示例（Usage Examples）。
   - 代码块内部关键地方必须撰写注释，**重点解释“为什么这么做”（设计意图、业务背景、并发安全理由或折衷方案）**，严禁仅机械复述“做了什么”。

---

## 2. 开发决策路由树 (Decision Routing Tree)

根据当前任务场景，快速定位并应用对应规范模块：

```mermaid
graph TD
    Start[接收到 Go 开发任务] --> Mode{任务类型}

    Mode -->|新建项目 Greenfield| GFlow[进入 Greenfield 流程: 基准 Go 1.23+]
    Mode -->|修改/重构已有项目 Brownfield| BFlow[进入 Brownfield 流程]
    Mode -->|Web 页面/全栈开发 Web UI| WFlow[进入 Web UI & Embed 流程]

    GFlow --> Scale{评估项目规模}
    Scale -->|Small: CLI/脚本/单模块| S1[Root main.go + internal/ 隔离结构]
    Scale -->|Medium: 独立服务/CRUD| S2[Standard Layout cmd/internal/pkg]
    Scale -->|Large: 企业微服务/DDD| S3[Clean / Hexagonal 架构]

    BFlow --> Inspect[探测项目现有规范: 日志/分层/错误/测试]
    Inspect --> Minimal[最小侵入性变更 + 兼容性保护]

    WFlow --> WebArch[Go html/template SSR + API + //go:embed]
    WebArch --> WebCSS[shadcn 纯 CSS Tokens + 原生 JS]
    WebArch --> WebSec[Session Cookie + CSRF + RBAC]

    S1 & S2 & S3 & Minimal & WebSec --> Core[遵循开发基础规范]
    Core --> LogObs[日志与可观测性 slog / OTel]
    Core --> ErrConc[错误链与并发安全]
    Core --> TestGate[表格驱动测试与 Quality Gate]
    Core --> DocComments[GoDoc 注释规范与意图说明]
```

---

## 3. 详细参考规范索引 (References Index)

各专题深度规范详见子文档，大模型在处理对应任务时可按需查阅：

| 模块 | 核心内容 | 参考文档路径 |
| :--- | :--- | :--- |
| **01. 规模分级与目录结构** | Small (Root main + internal/) / Medium (Standard Layout) / Large (Clean/DDD) 架构范式与选型规则 | [01_scale_and_structures.md](./references/01_scale_and_structures.md) |
| **02. 新建与存量改造 SOP** | 基准 Go 1.23+；Greenfield 骨架生成流水线；Brownfield 代码探测、向后兼容、Option 模式与防回归规范 | [02_greenfield_and_brownfield.md](./references/02_greenfield_and_brownfield.md) |
| **03. 日志与可观测性** | `log/slog` 结构化日志、TraceID 注入、RED 指标采集、链路追踪适用边界（小中型不强制）、探针 | [03_logging_and_observability.md](./references/03_logging_and_observability.md) |
| **04. 测试与质量门禁** | 表格驱动测试、`testify` 断言、接口 Mock (gomock/testify)、并发竞争检测 (`-race`)、Fuzzing | [04_testing_and_quality.md](./references/04_testing_and_quality.md) |
| **05. 错误处理与并发安全** | `%w` 包装、`errors.Is/As` 判定、自定义业务错误、`errgroup` 异步并发控制、Channel 所有权 | [05_errors_and_concurrency.md](./references/05_errors_and_concurrency.md) |
| **06. Go 惯用语法与陷阱** | 零值可用、函数式选项 (Functional Options)、防内存泄漏、Goroutine 泄露排查、命名缩写规则 | [06_idiomatic_go_best_practices.md](./references/06_idiomatic_go_best_practices.md) |
| **07. Web 页面与全栈嵌入** | 原生现代 JS/CSS/HTML5、Go 模板 (SSR) + API 混合架构、shadcn 样式、`//go:embed` 单二进制打包、认证与 CSRF 安全防护 | [07_web_ui_and_templating.md](./references/07_web_ui_and_templating.md) |
| **08. 代码注释与文档规范** | 官方 GoDoc 标准、导出标识符注释（以名称开头）、关键函数使用示例、代码内部解释“为什么”而非“做什么” | [08_documentation_and_comments.md](./references/08_documentation_and_comments.md) |

### 3.1 官方最佳实践基准与兜底 (Official Baseline & Fallbacks)

对于本规范未明确穷尽之场景、语法争议或架构细节，**必须以 Go 官方权威规范与业界公认最佳实践为最高准则**：

1. **[Effective Go](https://go.dev/doc/effective_go)**: 官方关于命名规范、控制流结构、初始化、接口设计、并发模型的权威经典指南。
2. **[Go Code Review Comments](https://go.dev/wiki/CodeReviewComments)**: Go 官方开发团队日常 Code Review 常见问题清单（包含缩写命名、上下文传递、错误字符串格式等细节）。
3. **[Go Doc Comments](https://go.dev/doc/comment)**: Go 官方文档注释语法与格式标准。
4. **[Uber Go Style Guide](https://github.com/uber-go/guide/blob/master/style.md)**: 业界经过大规模生产验证的工程化风格与避坑手册。
5. **Go Standard Library Idioms**: 遇到抽象分歧时，优先参考标准库（如 `net/http`, `io`, `os`, `sync`）的组织与设计哲学。

---

## 4. 推荐配置与模板资源 (Templates)

- **Linter 配置**: [golangci.yml](./templates/golangci.yml)（包含 `gofumpt`, `govet`, `revive`, `staticcheck`, `errcheck` 等配置）
- **工程化构建**: [Makefile](./templates/Makefile)（支持 `make test`, `make race`, `make lint`, `make build` 等）
- **标准测试模板**: [standard_table_test.go](./templates/standard_table_test.go)（标准表格驱动测试骨架）
- **Web 全栈样板**:
  - [shadcn_tokens.css](./templates/web/shadcn_tokens.css)（纯现代 CSS shadcn 设计系统）
  - [base_layout.html](./templates/web/base_layout.html)（Go `html/template` 响应式基础布局与深色模式）
  - [embed_server.go](./templates/web/embed_server.go)（生产级单二进制 Web 服务骨架，含 embed.FS/CSRF/Auth/Security Headers）

---

## 5. 快速执行检查清单 (Pre-Commit / Pre-Delivery Checklist)

在交付任何 Go 代码前，执行自检：
- [ ] 确保开发环境与 `go.mod` 基准版本为 Go 1.23+。
- [ ] `go vet ./...` 与 `golangci-lint run` 无任何告警。
- [ ] `go test -race ./...` 全部通过，无数据竞争与 Goroutine 泄漏。
- [ ] 所有被调用的函数错误均已检查并恰当处理/包装。
- [ ] 所有导出的结构体、函数、方法均有 GoDoc 完整注释（第一句以标识符名称开头）。
- [ ] 关键业务函数与核心工具类，注释中已附带清晰的使用示例代码。
- [ ] 代码块内部关键处（锁、通道、算法分支、异常折衷）均有注释阐释“为什么这么做”。
- [ ] 外部 I/O 与长耗时调用均传递了 `ctx context.Context`。
- [ ] （若含 Web 页面）所有模板变量均经由 `html/template` 安全自动转义，无 XSS 隐患。
- [ ] （若含 Web 页面）静态资源已正确配置 `//go:embed` 与强缓存标头。
- [ ] （若含 Web 页面）状态修改请求必须经过 CSRF Token 校验，Cookie 标记为 `HttpOnly` 与 `SameSite=Lax`。
