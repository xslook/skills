package example_test

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// 待测核心接口与数据结构示例
var ErrNotFound = errors.New("record not found")

type User struct {
	ID    string
	Email string
}

type UserRepository interface {
	FindByID(ctx context.Context, id string) (*User, error)
}

type UserService struct {
	repo UserRepository
}

func NewUserService(repo UserRepository) *UserService {
	return &UserService{repo: repo}
}

func (s *UserService) GetUser(ctx context.Context, id string) (*User, error) {
	if id == "" {
		return nil, errors.New("empty user id")
	}
	return s.repo.FindByID(ctx, id)
}

// 模拟 Mock 实现（也可用 mockgen / testify/mock 生成）
type fakeUserRepo struct {
	findFn func(ctx context.Context, id string) (*User, error)
}

func (f *fakeUserRepo) FindByID(ctx context.Context, id string) (*User, error) {
	return f.findFn(ctx, id)
}

// 标准表格驱动测试
func TestUserService_GetUser(t *testing.T) {
	t.Parallel()

	type fields struct {
		findFn func(ctx context.Context, id string) (*User, error)
	}
	type args struct {
		ctx context.Context
		id  string
	}

	tests := []struct {
		name     string
		fields   fields
		args     args
		wantUser *User
		wantErr  error
		checkErr func(t *testing.T, err error)
	}{
		{
			name: "成功查询已有用户",
			fields: fields{
				findFn: func(ctx context.Context, id string) (*User, error) {
					return &User{ID: "u-123", Email: "test@example.com"}, nil
				},
			},
			args: args{
				ctx: context.Background(),
				id:  "u-123",
			},
			wantUser: &User{ID: "u-123", Email: "test@example.com"},
			wantErr:  nil,
		},
		{
			name: "查询空 ID 报错",
			fields: fields{
				findFn: nil, // 不应触发 repo 调用
			},
			args: args{
				ctx: context.Background(),
				id:  "",
			},
			wantUser: nil,
			checkErr: func(t *testing.T, err error) {
				require.Error(t, err)
				assert.Contains(t, err.Error(), "empty user id")
			},
		},
		{
			name: "用户不存在返回 ErrNotFound",
			fields: fields{
				findFn: func(ctx context.Context, id string) (*User, error) {
					return nil, ErrNotFound
				},
			},
			args: args{
				ctx: context.Background(),
				id:  "u-404",
			},
			wantUser: nil,
			wantErr:  ErrNotFound,
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			repo := &fakeUserRepo{findFn: tt.fields.findFn}
			svc := NewUserService(repo)

			got, err := svc.GetUser(tt.args.ctx, tt.args.id)

			if tt.wantErr != nil {
				require.Error(t, err)
				assert.ErrorIs(t, err, tt.wantErr)
				assert.Nil(t, got)
				return
			}

			if tt.checkErr != nil {
				tt.checkErr(t, err)
				assert.Nil(t, got)
				return
			}

			require.NoError(t, err)
			assert.Equal(t, tt.wantUser, got)
		})
	}
}
